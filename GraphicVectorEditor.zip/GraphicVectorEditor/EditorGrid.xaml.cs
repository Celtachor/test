﻿using GraphicVectorEditor.Core;
using GraphicVectorEditor.Creation;
using GraphicVectorEditor.IO;
using GraphicVectorEditor.UI;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor
{
    /// <summary>
    /// Interaction logic for EditorGrid.xaml
    /// </summary>
    public partial class EditorGrid : UserControl
    {
        EditorManager editorManager;

        ActiveShapeFSM activeShapeFSM;

        IIOHelper saver;

        public EditorGrid()
        {
            InitializeComponent();
            editorManager = new EditorManager(canvas, this);
            activeShapeFSM = new ActiveShapeFSM(tbThickness, grdColor, editorManager);
            editorManager.NotifyStateChanged += shapeEditor_NotifyStateChanged;
            editorManager.NotifySelectedChanged += shapeEditor_NotifySelectedChanged;
            saver = new XmlIOHelper();
        }

        void shapeEditor_NotifySelectedChanged(Shape previous, Shape current)
        {
            activeShapeFSM.Update(current == null ? null : current.GetType());
            this.Focus();
        }

        void shapeEditor_NotifyStateChanged(EditorState previous, EditorState current)
        {
            switch (current)
            {
                case EditorState.Dragging: Cursor = Cursors.Hand; break;
                case EditorState.Dropping: Cursor = Cursors.Pen; break;
                case EditorState.Idle: Cursor = Cursors.Arrow; break;
                case EditorState.Stretching: Cursor = Cursors.SizeAll; break;
                default: throw new Exception("Unknown editor state");
            }
        }

        private void ShapeClick(object sender, RoutedEventArgs e)
        {
            var shape = ShapeCreator.Create((string)((Button)sender).Tag);
            editorManager.SetShapeToDrop(shape);
        }

        private void UserControl_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Escape: editorManager.SetShapeToDrop(null); break;
                case Key.Delete: editorManager.DeleteSelected(); break;
                case Key.Up: editorManager.MoveSelected(new Vector(0, -1)); break;
                case Key.Down: editorManager.MoveSelected(new Vector(0, 1)); break;
                case Key.Left: editorManager.MoveSelected(new Vector(-1, 0)); break;
                case Key.Right: editorManager.MoveSelected(new Vector(1, 0)); break;
            }
        }

        private void Canvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Focus();
            var position = Mouse.GetPosition(canvas);
            if (editorManager.IsNearSelectedShape(position))
            {
                if (e.ClickCount == 2)
                    editorManager.Modify(editorManager.SelectedShape);
            }
            else
            {
                editorManager.SelectShape(null);
                if (!editorManager.Drop())
                    mousePosition = position;
            }
            e.Handled = true;
        }

        private void Canvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            editorManager.RotateSelected(e.Delta / 100);
        }

        private void Color_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Forms.ColorDialog colorDialog = new System.Windows.Forms.ColorDialog();
            if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var color = new System.Windows.Media.Color();
                color.A = 255;
                color.R = colorDialog.Color.R;
                color.G = colorDialog.Color.G;
                color.B = colorDialog.Color.B;
                ((Grid)sender).Background = new SolidColorBrush(color);
                Color_MouseLeftButtonDown(sender, e);
            }
        }

        private void Color_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            editorManager.DyeSelected(((SolidColorBrush)((Grid)sender).Background).Color);
        }

        private void Canvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Focus();
            if (editorManager.SelectedShape != null)
                editorManager.Stretch();
        }

        Point? mousePosition;
        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.RightButton == MouseButtonState.Pressed)
                editorManager.Stretch();
            else if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (editorManager.SelectedShape != null)
                    editorManager.MoveSelected();
                else
                {
                    if (mousePosition.HasValue)
                    {
                        if (Cursor != Cursors.ScrollAll)
                            Cursor = Cursors.ScrollAll;
                        var point = Mouse.GetPosition(canvas);
                        var vector = point - mousePosition.Value;
                        var x = translate.X + vector.X;
                        var y = translate.Y + vector.Y;
                        if (x < 0 && x > -canvas.Width + container.ActualWidth)
                            translate.X = x;
                        if (y < 0 && y > -canvas.Height + container.ActualHeight)
                            translate.Y = y;
                    }
                }
            }
        }

        private void tbThickness_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up:
                    if (string.IsNullOrEmpty(tbThickness.Text))
                        tbThickness.Text = "1";
                    else
                        tbThickness.Text = (int.Parse(tbThickness.Text) + 1).ToString();
                    break;
                case Key.Down:
                    if (string.IsNullOrEmpty(tbThickness.Text))
                        tbThickness.Text = "1";
                    else
                    {
                        int i = int.Parse(tbThickness.Text) - 1;
                        if (i > 0)
                            tbThickness.Text = i.ToString();
                    }
                    break;
            }
        }

        private void tbThickness_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            int i;
            e.Handled = !int.TryParse(e.Text, out i);
        }

        private void tbThickness_TextChanged(object sender, TextChangedEventArgs e)
        {
            int maxThickness = 500;
            if (!string.IsNullOrEmpty(tbThickness.Text))
            {
                int thickness = int.Parse(tbThickness.Text);
                if (thickness <= maxThickness)
                    editorManager.SetThickness(thickness);
            }
        }

        private void SaveClick(object sender, RoutedEventArgs e)
        {
            editorManager.SelectShape(null);
            try
            {
                saver.Save(translate.X, translate.Y, canvas);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Window.GetWindow(this), ex.Message, "ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OpenClick(object sender, RoutedEventArgs e)
        {
            editorManager.SetShapeToDrop(null);
            try
            {
                var data = saver.Open();
                if (data != null)
                {
                    canvas.Children.Clear();
                    translate.X = data.Item1;
                    translate.Y = data.Item2;
                    editorManager.Insert(data.Item3);
                    activeShapeFSM.Update(null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Window.GetWindow(this), ex.Message, "ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Canvas_MouseLeave(object sender, MouseEventArgs e)
        {
            mousePosition = null;
            Cursor = Cursors.Arrow;
        }
    }
}
