﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core
{
    public enum EditorState
    {
        Idle,
        Dropping,
        Dragging,
        Stretching
    }

    public class ShapeEditor
    {
        public delegate void EditorStateChangedEventHandler(EditorState previous, EditorState current);
        public event EditorStateChangedEventHandler NotifyStateChanged;

        EditorState state;
        public EditorState State
        {
            get
            {
                return state;
            }
            set
            {
                if (value != state)
                {
                    state = value;
                    if (NotifyStateChanged != null)
                        NotifyStateChanged(state, value);
                }
            }
        }

        Shape shapeToDrop;

        public delegate void SelectedChangedEventHandler(Shape previous, Shape current);
        public event SelectedChangedEventHandler NotifySelectedChanged;

        private Shape selectedShape;
        public Shape SelectedShape
        {
            get
            {
                return selectedShape;
            }
            private set
            {
                if (value != selectedShape)
                {
                    selectedShape = value;
                    if (NotifySelectedChanged != null)
                        NotifySelectedChanged(selectedShape, value);
                }
            }
        }

        Brush selectedShapeStroke;

        Canvas canvas;

        RectEditor rectEditor;
        PolylineEditor polylineEditor;

        public ShapeEditor(Canvas canvas)
        {
            this.canvas = canvas;
            State = EditorState.Idle;
            canvas.MouseUp += canvas_MouseUp;
            rectEditor = new RectEditor(this, canvas);
            polylineEditor = new PolylineEditor(this, canvas);
        }

        #region Functional

        /// <summary>
        /// Устанавливает фигуру для размещения на рабочей области.
        /// </summary>
        /// <param name="shape">Фигура, которую надо разместить на рабочей области.</param>
        public void SetShapeToDrop(Shape shape)
        {
            shapeToDrop = shape;
            SelectShape(null);
            if (shapeToDrop == null)
                State = EditorState.Idle;
            else
                State = EditorState.Dropping;
        }

        /// <summary>
        /// Размещает фигуру на рабочей области.
        /// </summary>
        public bool Drop()
        {
            if (shapeToDrop != null)
            {
                var point = Mouse.GetPosition(canvas);
                canvas.Children.Add(shapeToDrop);
                var offset = shapeToDrop.Tag is Vector ? (Vector)shapeToDrop.Tag : new Vector();
                SetLeftTop(shapeToDrop, (point + offset).X, (point + offset).Y);
                shapeToDrop.MouseLeftButtonDown += shapeToDrop_MouseLeftButtonDown;
                shapeToDrop.MouseRightButtonDown += shapeToDrop_MouseRightButtonDown;
                SelectShape(shapeToDrop);
                shapeToDrop = null;
                State = EditorState.Idle;
                return true;
            }
            return false;
        }

        public void Insert(List<Shape> shapes)
        {
            for (int i = 0; i < shapes.Count; i++)
            {
                var shape = shapes[i];
                canvas.Children.Add(shape);
                shape.MouseLeftButtonDown += shapeToDrop_MouseLeftButtonDown;
                shape.MouseRightButtonDown += shapeToDrop_MouseRightButtonDown;
            }
            State = EditorState.Idle;
        }

        public void Stretch()
        {
            if (SelectedShape != null)
            {
                if (SelectedShape is Rectangle)
                    rectEditor.Stretch((Rectangle)SelectedShape);
                else if (SelectedShape is Polyline)
                    polylineEditor.Edit((Polyline)SelectedShape);
            }
        }

        /// <summary>
        /// Вращает фигуру (прямоугольник).
        /// </summary>
        /// <param name="angle">Относительная величина угла поворота.</param>
        public void RotateSelected(double angle)
        {
            if (SelectedShape != null)
            {
                if (SelectedShape is Rectangle)
                {
                    angle /= 100;
                    Vector? vector = null;
                    vector = (Vector)SelectedShape.Tag;
                    if (SelectedShape.RenderTransform is RotateTransform)
                        angle += ((RotateTransform)SelectedShape.RenderTransform).Angle;
                    var rotateTransform = new RotateTransform(angle, -vector.Value.X, -vector.Value.Y);
                    SelectedShape.RenderTransform = rotateTransform;
                }
            }
        }

        /// <summary>
        /// Устанавливает выбранную фигуру.
        /// </summary>
        /// <param name="shape">Выбранная фигура.</param>
        public void SelectShape(Shape shape)
        {
            if (SelectedShape != shape)
            {
                if (SelectedShape != null)
                {
                    if (SelectedShape is Rectangle)
                        SelectedShape.Stroke = selectedShapeStroke;
                    if (SelectedShape is Polyline)
                        polylineEditor.Deselect();
                }
                SelectedShape = shape;
                if (SelectedShape != null)
                {
                    if (SelectedShape is Rectangle)
                    {
                        selectedShapeStroke = SelectedShape.Stroke;
                        SelectedShape.Stroke = Brushes.Blue;
                    }
                    else if (SelectedShape is Polyline)
                        polylineEditor.Select((Polyline)SelectedShape);
                }
            }
        }

        /// <summary>
        /// Удаляет выбранную фигуру из рабочей области.
        /// </summary>
        public void DeleteSelected()
        {
            if (SelectedShape != null)
            {
                if (SelectedShape is Polyline)
                    polylineEditor.Delete((Polyline)SelectedShape);
                else
                    canvas.Children.Remove(SelectedShape);
                SelectedShape = null;
            }
        }

        /// <summary>
        /// Устанавливает толщину.
        /// </summary>
        /// <param name="thickness">Толщина.</param>
        public void SetThickness(int thickness)
        {
            if (SelectedShape is Polyline)
                polylineEditor.SetThickness((Polyline)SelectedShape, thickness);
        }

        /// <summary>
        /// Устанавливает цвет заливки выбранной фигуры (прямоугольника).
        /// </summary>
        /// <param name="color">Цвет заливки.</param>
        public void Dye(Color color)
        {
            if (SelectedShape != null)
            {
                if (SelectedShape is Rectangle)
                    rectEditor.Dye((Rectangle)SelectedShape, color);
                else if (SelectedShape is Polyline)
                    polylineEditor.Dye((Polyline)SelectedShape, color);
                selectedShapeStroke = new SolidColorBrush(color);
            }
        }

        public Color? GetSelectedShapeColor()
        {
            if (SelectedShape != null)
            {
                if (SelectedShape is Rectangle)
                    return rectEditor.GetColor((Rectangle)SelectedShape);
                if (SelectedShape is Polyline)
                    return polylineEditor.GetColor((Polyline)SelectedShape);
                throw new Exception("Unknown type of shape");
            }
            return null;
        }

        /// <summary>
        /// Перемещает выбранную фигуру по рабочей области.
        /// </summary>
        /// <param name="vector">Вектор перемещения.</param>
        public void MoveSelected(Vector vector)
        {
            if (SelectedShape != null)
            {
                Move(SelectedShape, vector);
                State = EditorState.Dragging;
            }
        }

        /// <summary>
        /// Перемещает фигуру по рабочей области на вектор.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="vector">Вектор перемещения.</param>
        public void Move(Shape shape, Vector vector)
        {
            var leftTop = GetLeftTop(shape);
            leftTop += vector;
            SetLeftTop(shape, leftTop.X, leftTop.Y);
        }

        /// <summary>
        /// Перемещает фигуру по рабочей области в след за мышью.
        /// </summary>
        /// <param name="shape">Фигура</param>
        public void Move(Shape shape)
        {
            var leftTop = GetLeftTop(shape);
            var center = GetCenter(shape, leftTop);
            var vector = Mouse.GetPosition(canvas) - center;
            if (shape is Polyline)
                polylineEditor.Move((Polyline)shape, vector);
            else
                Move(shape, vector);
            State = EditorState.Dragging;
        }

        #endregion

        #region Helpful functions

        /// <summary>
        /// Вращает вектор против часовой стрелки.
        /// </summary>
        /// <param name="vector">Вектор.</param>
        /// <param name="angle">Угол в градусах.</param>
        public Vector RotateVector(Vector vector, double angle)
        {
            var alpha = Math.Atan2(vector.Y, vector.X);
            alpha += angle * Math.PI / 180;
            var x = vector.Length * Math.Cos(alpha);
            var y = vector.Length * Math.Sin(alpha);
            return new Vector(x, y);
        }

        /// <summary>
        /// Возвращает верхнюю левую точку фигуры.
        /// </summary>
        public Point GetLeftTop(Shape shape)
        {
            var x = Canvas.GetLeft(shape);
            var y = Canvas.GetTop(shape);
            return new Point(x, y);
        }

        /// <summary>
        /// Задает верхнюю левую точку фигуры.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="x">X координата.</param>
        /// <param name="y">Y координата.</param>
        public void SetLeftTop(Shape shape, double x, double y)
        {
            Canvas.SetLeft(shape, x);
            Canvas.SetTop(shape, y);
        }

        /// <summary>
        /// Возвращает точку, привязываемую к курсору при перемещении фигуры.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="leftTop">Верхняя левая точка фигуры.</param>
        public Point GetCenter(Shape shape, Point leftTop)
        {
            return leftTop - (shape.Tag is Vector ? (Vector)shape.Tag : new Vector());
        }

        #endregion

        #region Logic

        void shapeToDrop_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            SelectShape((Shape)sender);
            e.Handled = true;
        }

        void shapeToDrop_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is Polyline)
            {
                var polyline = (Polyline)sender;
                var mouse = Mouse.GetPosition(canvas);
                var lt = GetLeftTop(polyline);
                polyline.Tag = lt - mouse;
                if (e.ClickCount == 2)
                {
                    polylineEditor.Bend(polyline);
                    polylineEditor.Deselect();
                    polylineEditor.Select(polyline);
                }
            }
            SelectShape((Shape)sender);
            e.Handled = true;
        }

        void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (State != EditorState.Dropping)
                State = EditorState.Idle;
        }

        #endregion
    }
}
