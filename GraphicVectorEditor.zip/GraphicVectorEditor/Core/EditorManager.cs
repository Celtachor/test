﻿using GraphicVectorEditor.Core.Editors;
using GraphicVectorEditor.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core
{
    public enum EditorState
    {
        Idle,
        Dropping,
        Dragging,
        Stretching
    }

    public class EditorManager
    {
        public delegate void EditorStateChangedEventHandler(EditorState previous, EditorState current);
        public event EditorStateChangedEventHandler NotifyStateChanged;

        EditorState state;
        public EditorState State
        {
            get
            {
                return state;
            }
            set
            {
                if (value != state)
                {
                    state = value;
                    if (NotifyStateChanged != null)
                        NotifyStateChanged(state, value);
                }
            }
        }

        Shape shapeToDrop;

        public delegate void SelectedChangedEventHandler(Shape previous, Shape current);
        public event SelectedChangedEventHandler NotifySelectedChanged;

        private Shape selectedShape;
        public Shape SelectedShape
        {
            get
            {
                return selectedShape;
            }
            private set
            {
                if (value != selectedShape)
                {
                    var previous = selectedShape;
                    selectedShape = value;
                    if (selectedShape == null)
                        editor = null;
                    else if (!shapeTypeToEditor.TryGetValue(selectedShape.GetType(), out editor))
                        throw new Exception("Unknown type of shape");
                    if (NotifySelectedChanged != null)
                        NotifySelectedChanged(previous, selectedShape);
                }
            }
        }

        internal Brush SelectedShapeStroke;

        Dictionary<Type, Editor> shapeTypeToEditor;

        Editor editor;

        Canvas canvas;

        UserControl mainContainer;

        public EditorManager(Canvas canvas, UserControl mainContainer)
        {
            this.canvas = canvas;
            this.mainContainer = mainContainer;
            State = EditorState.Idle;
            canvas.MouseUp += canvas_MouseUp;
            shapeTypeToEditor = new Dictionary<Type, Editor>()
            {
                { typeof(Rectangle), new RectEditor(this, canvas) },
                { typeof(Polyline), new PolylineEditor(this, canvas) }
            };
        }

        #region Functional

        /// <summary>
        /// Устанавливает фигуру для размещения на рабочей области.
        /// </summary>
        /// <param name="shape">Фигура, которую надо разместить на рабочей области.</param>
        public void SetShapeToDrop(Shape shape)
        {
            shapeToDrop = shape;
            SelectShape(null);
            if (shapeToDrop == null)
                State = EditorState.Idle;
            else
                State = EditorState.Dropping;
        }

        /// <summary>
        /// Размещает фигуру на рабочей области.
        /// </summary>
        public bool Drop()
        {
            if (shapeToDrop != null)
            {
                var point = Mouse.GetPosition(canvas);
                canvas.Children.Add(shapeToDrop);
                var offset = shapeToDrop.Tag is Vector ? (Vector)shapeToDrop.Tag : new Vector();
                SetLeftTop(shapeToDrop, (point + offset).X, (point + offset).Y);
                shapeToDrop.MouseLeftButtonDown += shapeToDrop_MouseLeftButtonDown;
                shapeToDrop.MouseRightButtonDown += shapeToDrop_MouseRightButtonDown;
                SelectShape(shapeToDrop);
                shapeToDrop = null;
                State = EditorState.Idle;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Помещает на рабочую область список фигур.
        /// </summary>
        public void Insert(List<Shape> shapes)
        {
            for (int i = 0; i < shapes.Count; i++)
            {
                var shape = shapes[i];
                canvas.Children.Add(shape);
                shape.MouseLeftButtonDown += shapeToDrop_MouseLeftButtonDown;
                shape.MouseRightButtonDown += shapeToDrop_MouseRightButtonDown;
            }
            State = EditorState.Idle;
        }

        /// <summary>
        /// Изменяет размеры фигуры.
        /// </summary>
        public void Stretch()
        {
            if (SelectedShape != null)
                editor.Stretch(SelectedShape);
        }

        /// <summary>
        /// Вращает фигуру (прямоугольник).
        /// </summary>
        /// <param name="angle">Угол поворота в градусах.</param>
        public void RotateSelected(double angle)
        {
            if (SelectedShape != null)
                editor.Rotate(SelectedShape, angle);
        }

        /// <summary>
        /// Устанавливает выбранную фигуру.
        /// </summary>
        /// <param name="shape">Выбранная фигура.</param>
        public void SelectShape(Shape shape)
        {
            if (SelectedShape != shape)
            {
                if (SelectedShape != null)
                    editor.Deselect();
                SelectedShape = shape;
                if (SelectedShape != null)
                    editor.Select(SelectedShape);
            }
            Keyboard.ClearFocus();
            mainContainer.Focus();
        }

        /// <summary>
        /// Удаляет выбранную фигуру из рабочей области.
        /// </summary>
        public void DeleteSelected()
        {
            if (SelectedShape != null)
            {
                editor.Delete(SelectedShape);
                SelectedShape = null;
            }
        }

        /// <summary>
        /// Устанавливает толщину.
        /// </summary>
        /// <param name="thickness">Толщина.</param>
        public void SetThickness(int thickness)
        {
            if (SelectedShape != null)
                editor.SetThickness(SelectedShape, thickness);
        }

        /// <summary>
        /// Устанавливает цвет заливки выбранной фигуры (прямоугольника).
        /// </summary>
        /// <param name="color">Цвет заливки.</param>
        public void DyeSelected(Color color)
        {
            if (SelectedShape != null)
                editor.Dye(SelectedShape, color);
        }

        /// <summary>
        /// Возвращает цвет выбранной фигуры.
        /// </summary>
        public Color? GetSelectedShapeColor()
        {
            if (SelectedShape != null)
                return editor.GetColor(SelectedShape);
            return null;
        }

        /// <summary>
        /// Перемещает выбранную фигуру по рабочей области.
        /// </summary>
        /// <param name="vector">Вектор перемещения.</param>
        public void MoveSelected(Vector vector)
        {
            if (SelectedShape != null)
                Move(SelectedShape, vector);
        }

        /// <summary>
        /// Перемещает фигуру по рабочей области на вектор.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="vector">Вектор перемещения.</param>
        public void Move(Shape shape, Vector vector)
        {
            editor.Move(SelectedShape, vector);
            State = EditorState.Dragging;
        }

        /// <summary>
        /// Перемещает фигуру по рабочей области в след за мышью.
        /// </summary>
        /// <param name="shape">Фигура</param>
        public void MoveSelected()
        {
            if (SelectedShape != null)
            {
                var leftTop = GetLeftTop(SelectedShape);
                var center = GetCenter(SelectedShape, leftTop);
                var vector = Mouse.GetPosition(canvas) - center;
                Move(SelectedShape, vector);
            }
        }

        /// <summary>
        /// Меняет форму фигуры.
        /// </summary>
        public void Modify(Shape shape)
        {
            if (SelectedShape != null)
                editor.Modify(SelectedShape);
        }

        /// <summary>
        /// Возвращает True, если расстояние от точки до выбранной тонкой фигуры не превышает максимального (precision). В противном случае - False.
        /// </summary>
        /// <param name="point">Точка.</param>
        public bool IsNearSelectedShape(Point point)
        {
            double precision = 3;
            if (SelectedShape != null && SelectedShape is Polyline)
            {
                var polyline = (Polyline)SelectedShape;
                var position = GetLeftTop(polyline);
                var sections = new List<Section>();
                for (int i = 1; i < polyline.Points.Count; i++)
                {
                    var point1 = polyline.Points[i - 1];
                    var point2 = polyline.Points[i];
                    sections.Add(new Section(new Point(point1.X + position.X, point1.Y + position.Y), new Point(point2.X + position.X, point2.Y + position.Y)));
                }
                var isNear = sections.Min(section => section.GetDistance(point)) < precision;
                if (isNear)
                    polyline.Tag = position - point;
                return isNear;
            }
            return false;
        }

        #endregion

        #region Helpful functions

        /// <summary>
        /// Вращает вектор против часовой стрелки.
        /// </summary>
        /// <param name="vector">Вектор.</param>
        /// <param name="angle">Угол в градусах.</param>
        public Vector RotateVector(Vector vector, double angle)
        {
            var alpha = Math.Atan2(vector.Y, vector.X);
            alpha += angle * Math.PI / 180;
            var x = vector.Length * Math.Cos(alpha);
            var y = vector.Length * Math.Sin(alpha);
            return new Vector(x, y);
        }

        /// <summary>
        /// Возвращает верхнюю левую точку фигуры.
        /// </summary>
        public Point GetLeftTop(Shape shape)
        {
            var x = Canvas.GetLeft(shape);
            var y = Canvas.GetTop(shape);
            return new Point(x, y);
        }

        /// <summary>
        /// Задает верхнюю левую точку фигуры.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="x">X координата.</param>
        /// <param name="y">Y координата.</param>
        public void SetLeftTop(Shape shape, double x, double y)
        {
            Canvas.SetLeft(shape, x);
            Canvas.SetTop(shape, y);
        }

        /// <summary>
        /// Возвращает точку, привязываемую к курсору при перемещении фигуры.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="leftTop">Верхняя левая точка фигуры.</param>
        public Point GetCenter(Shape shape, Point leftTop)
        {
            return leftTop - (shape.Tag is Vector ? (Vector)shape.Tag : new Vector());
        }

        #endregion

        #region Logic

        void shapeToDrop_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            SelectShape((Shape)sender);
            e.Handled = true;
        }

        void shapeToDrop_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (State != EditorState.Dropping)
            {
                var shape = (Shape)sender;
                if (sender is Polyline)
                {
                    var mouse = Mouse.GetPosition(canvas);
                    var leftTop = GetLeftTop(shape);
                    shape.Tag = leftTop - mouse;
                }
                if (e.ClickCount == 2)
                    Modify(shape);
                SelectShape(shape);
                e.Handled = true;
            }
        }

        void canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (State != EditorState.Dropping)
                State = EditorState.Idle;
        }

        #endregion
    }
}
