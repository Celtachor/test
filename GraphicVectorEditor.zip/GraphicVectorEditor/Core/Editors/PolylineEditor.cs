﻿using GraphicVectorEditor.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core.Editors
{
    public class PolylineEditor : Editor
    {
        List<Ellipse> tempElements = new List<Ellipse>();

        public PolylineEditor(EditorManager manager, Canvas canvas)
            : base(manager, canvas)
        { }

        /// <summary>
        /// Перемещает излом ломанной линии.
        /// </summary>
        public override void Stretch(Shape shape)
        {
            if (tempElements != null && tempElements.Count > 0)
            {
                var polyline = (Polyline)shape;
                manager.State = EditorState.Stretching;
                var mouse = Mouse.GetPosition(canvas);
                var circle = tempElements.OrderBy(t => (mouse - new Point(Canvas.GetLeft(t) + t.Width / 2, Canvas.GetTop(t) + t.Height / 2)).Length).First();
                double treshold = polyline.StrokeThickness + circle.Height / 2;
                var index = tempElements.IndexOf(circle);
                var leftTop = manager.GetLeftTop(polyline);
                var point = new Point(mouse.X - leftTop.X, mouse.Y - leftTop.Y);
                if ((index > 0 && (point - polyline.Points[index - 1]).Length < treshold) ||
                    (index < polyline.Points.Count - 1 && (point - polyline.Points[index + 1]).Length < treshold))
                {
                    if (polyline.Points.Count > 2)
                    {
                        polyline.Points.RemoveAt(index);
                        canvas.Children.Remove(circle);
                        tempElements.Remove(circle);
                    }
                }
                else
                {
                    polyline.Points[index] = point;
                    manager.SetLeftTop(circle, mouse.X - circle.Width / 2, mouse.Y - circle.Height / 2);
                }
            }
        }

        /// <summary>
        /// Показывает точки излома на ломанной линии.
        /// </summary>
        public override void Select(Shape shape)
        {
            var polyline = (Polyline)shape;
            var position = manager.GetLeftTop(polyline);
            for (int i = 0; i < polyline.Points.Count; i++)
            {
                var point = polyline.Points[i];
                var circle = new Ellipse();
                circle.Stroke = Brushes.Blue;
                circle.Fill = Brushes.White;
                circle.Width = polyline.StrokeThickness + 6;
                circle.Height = polyline.StrokeThickness + 6;
                circle.Tag = "temp";
                canvas.Children.Add(circle);
                manager.SetLeftTop(circle, position.X + point.X - circle.Width / 2, position.Y + point.Y - circle.Height / 2);
                tempElements.Add(circle);
                circle.MouseDown += circle_MouseDown;
            }
        }

        /// <summary>
        /// Удаляет обозначения точек излома на ломанной линии.
        /// </summary>
        public override void Deselect()
        {
            if (tempElements != null)
            {
                for (int i = 0; i < tempElements.Count; i++)
                    canvas.Children.Remove(tempElements[i]);
                tempElements.Clear();
            }
        }

        /// <summary>
        /// Удаляет ломанную линию.
        /// </summary>
        public override void Delete(Shape shape)
        {
            base.Delete(shape);
            Deselect();
        }

        /// <summary>
        /// Устанавливает толщину ломанной линии.
        /// </summary>
        /// <param name="polyline">Ломанная линия.</param>
        /// <param name="thickness">Толщина.</param>
        public override void SetThickness(Shape shape, int thickness)
        {
            if (shape.StrokeThickness != thickness)
            {
                shape.StrokeThickness = thickness;
                Deselect();
                Select(shape);
            }
        }

        /// <summary>
        /// Устанавливает цвет ломанной линии.
        /// </summary>
        /// <param name="shape">Ломанная линия.</param>
        /// <param name="color">Цвет.</param>
        public override void Dye(Shape shape, Color color)
        {
            shape.Stroke = new SolidColorBrush(color);
        }

        /// <summary>
        /// Возвращает цвет фигуры.
        /// </summary>
        public override Color GetColor(Shape shape)
        {
            return ((SolidColorBrush)shape.Stroke).Color;
        }

        /// <summary>
        /// Перемещает ломанную линию.
        /// </summary>
        /// <param name="vector"></param>
        public override void Move(Shape shape, Vector vector)
        {
            base.Move(shape, vector);
            if (tempElements != null)
            {
                for (int i = 0; i < tempElements.Count; i++)
                    base.Move((Shape)tempElements[i], vector);
            }
        }

        /// <summary>
        /// Создает излом на ломанной линии.
        /// </summary>
        public override void Modify(Shape shape)
        {
            var mousePoint = Mouse.GetPosition(canvas);
            var polyline = (Polyline)shape;
            var sectionsToIdx = new Dictionary<Section, int>();
            var position = manager.GetLeftTop(polyline);
            for (int i = 1; i < polyline.Points.Count; i++)
            {
                var point1 = polyline.Points[i - 1];
                var point2 = polyline.Points[i];
                sectionsToIdx.Add(new Section(new Point(point1.X + position.X, point1.Y + position.Y), new Point(point2.X + position.X, point2.Y + position.Y)), i);
            }
            int? idx = null;
            foreach (var section in sectionsToIdx.Keys.OrderBy(s => s.GetDistance(mousePoint)))
            {
                var length1 = (mousePoint - section.Point1).Length;
                var length2 = (mousePoint - section.Point2).Length;
                if (length1 < section.Length && length2 < section.Length)
                {
                    idx = sectionsToIdx[section];
                    break;
                }
            }
            if (idx.HasValue)
                polyline.Points.Insert(idx.Value, new Point(mousePoint.X - position.X, mousePoint.Y - position.Y));
            Deselect();
            Select(polyline);
        }

        void circle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                if (manager.SelectedShape is Polyline)
                {
                    var leftTop = manager.GetLeftTop(manager.SelectedShape);
                    manager.SelectedShape.Tag = leftTop - manager.GetLeftTop((Shape)sender);
                }
            }
            e.Handled = true;
        }

        public override void Rotate(Shape shape, double angle)
        { }
    }
}
