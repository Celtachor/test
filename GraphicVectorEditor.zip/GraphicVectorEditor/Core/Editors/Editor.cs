﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core.Editors
{
    public abstract class Editor
    {
        protected Canvas canvas;

        protected EditorManager manager;

        protected Editor(EditorManager manager, Canvas canvas)
        {
            this.manager = manager;
            this.canvas = canvas;
        }

        /// <summary>
        /// Изменяет размеры фигуры.
        /// </summary>
        public abstract void Stretch(Shape shape);

        /// <summary>
        /// Вращает фигуру на заданный угол.
        /// </summary>
        /// <param name="shape">Фигура.</param>
        /// <param name="angle">Угол.</param>
        public abstract void Rotate(Shape shape, double angle);

        /// <summary>
        /// Выделяет фигуру.
        /// </summary>
        public abstract void Select(Shape shape);

        /// <summary>
        /// Снимает выделение с выбранной фигуры.
        /// </summary>
        public abstract void Deselect();

        /// <summary>
        /// Удаляет фигуру.
        /// </summary>
        public virtual void Delete(Shape shape)
        {
            canvas.Children.Remove(shape);
        }

        /// <summary>
        /// Задает толщину фигуры.
        /// </summary>
        public abstract void SetThickness(Shape shape, int thickness);

        /// <summary>
        /// Задает цвет фигуры.
        /// </summary>
        public abstract void Dye(Shape shape, Color color);

        /// <summary>
        /// Возвращает цвет фигуры.
        /// </summary>
        public abstract Color GetColor(Shape shape);

        /// <summary>
        /// Перемещает фигуру.
        /// </summary>
        /// <param name="shape"></param>
        /// <param name="vector"></param>
        public virtual void Move(Shape shape, Vector vector)
        {
            var leftTop = manager.GetLeftTop(shape);
            leftTop += vector;
            manager.SetLeftTop(shape, leftTop.X, leftTop.Y);
        }

        /// <summary>
        /// Меняет форму фигуры.
        /// </summary>
        public abstract void Modify(Shape shape);
    }
}
