﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core.Editors
{
    public class RectEditor : Editor
    {
        public RectEditor(EditorManager manager, Canvas canvas)
            : base(manager, canvas)
        { }

        /// <summary>
        /// Изменяет размер прямоугольника.
        /// </summary>
        public override void Stretch(Shape shape)
        {
            var rect = (Rectangle)shape;
            manager.State = EditorState.Stretching;
            var leftTop = manager.GetLeftTop(rect);
            var mouse = Mouse.GetPosition(canvas);
            Vector vector1;
            var angle = rect.RenderTransform is RotateTransform ? ((RotateTransform)rect.RenderTransform).Angle : 0;
            if (angle != 0)
            {
                var vector0 = (Vector)rect.Tag;
                var center = manager.GetCenter(rect, leftTop);
                vector1 = mouse - center;
                vector1 = manager.RotateVector(vector1, -angle);
                vector1 -= vector0;
                vector0 = manager.RotateVector(vector0, angle);
                var O = center + vector0;
                vector0 = -vector1 / 2;
                vector0 = manager.RotateVector(vector0, angle);
                var O_ = leftTop + vector1 / 2 + vector0;
                leftTop += O - O_;
                manager.SetLeftTop(rect, leftTop.X, leftTop.Y);
            }
            else
                vector1 = mouse - leftTop;
            if (vector1.X > 0 && vector1.Y > 0)
            {
                rect.Width = vector1.X;
                rect.Height = vector1.Y;
                rect.Tag = -vector1 / 2;
                if (angle != 0)
                    rect.RenderTransform = new RotateTransform(angle, vector1.X / 2, vector1.Y / 2);
            }
        }

        /// <summary>
        /// Вращает прямоугольник на угол.
        /// </summary>
        /// <param name="shape">Прямоугольник.</param>
        /// <param name="angle">Угол поворота в градусах.</param>
        public override void Rotate(Shape shape, double angle)
        {
            Vector? vector = null;
            vector = (Vector)shape.Tag;
            if (shape.RenderTransform is RotateTransform)
                angle += ((RotateTransform)shape.RenderTransform).Angle;
            var rotateTransform = new RotateTransform(angle, -vector.Value.X, -vector.Value.Y);
            shape.RenderTransform = rotateTransform;
        }

        /// <summary>
        /// Выделяет прямоугольник.
        /// </summary>
        public override void Select(Shape shape)
        {
            manager.SelectedShapeStroke = manager.SelectedShape.Stroke;
            manager.SelectedShape.Stroke = Brushes.Blue;
        }

        /// <summary>
        /// Снимает выделение с выбранного прямоугольника.
        /// </summary>
        public override void Deselect()
        {
            manager.SelectedShape.Stroke = manager.SelectedShapeStroke;
        }

        /// <summary>
        /// Устанавливает цвет прямоугольника.
        /// </summary>
        /// <param name="shape">Прямоугольник.</param>
        /// <param name="color">Цвет.</param>
        public override void Dye(Shape shape, Color color)
        {
            shape.Fill = new SolidColorBrush(color);
            if (color == Colors.White)
                manager.SelectedShapeStroke = Brushes.Black;
            else
                manager.SelectedShapeStroke = new SolidColorBrush(color);
        }

        /// <summary>
        /// Возвращает цвет фигуры.
        /// </summary>
        public override Color GetColor(Shape shape)
        {
            return ((SolidColorBrush)shape.Fill).Color;
        }

        public override void SetThickness(Shape shape, int thickness)
        { }

        public override void Modify(Shape shape)
        { }
    }
}
