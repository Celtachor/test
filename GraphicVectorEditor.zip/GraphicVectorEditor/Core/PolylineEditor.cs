﻿using GraphicVectorEditor.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core
{
    public class PolylineEditor
    {
        ShapeEditor manager;

        Canvas canvas;

        List<Ellipse> tempElements = new List<Ellipse>();

        public PolylineEditor(ShapeEditor manager, Canvas canvas)
        {
            this.manager = manager;
            this.canvas = canvas;
        }

        /// <summary>
        /// Показывает точки излома на ломанной линии.
        /// </summary>
        public void Select(Polyline polyline)
        {
            var position = manager.GetLeftTop(polyline);
            for (int i = 0; i < polyline.Points.Count; i++)
            {
                var point = polyline.Points[i];
                var circle = new Ellipse();
                circle.Stroke = Brushes.Blue;
                circle.Fill = Brushes.White;
                circle.Width = polyline.StrokeThickness + 6;
                circle.Height = polyline.StrokeThickness + 6;
                circle.Tag = "temp";
                canvas.Children.Add(circle);
                manager.SetLeftTop(circle, position.X + point.X - circle.Width / 2, position.Y + point.Y - circle.Height / 2);
                tempElements.Add(circle);
                circle.MouseRightButtonDown += circle_MouseRightButtonDown;
            }
        }

        /// <summary>
        /// Удаляет обозначения точек излома на ломанной линии.
        /// </summary>
        public void Deselect()
        {
            if (tempElements != null)
            {
                for (int i = 0; i < tempElements.Count; i++)
                    canvas.Children.Remove(tempElements[i]);
                tempElements.Clear();
            }
        }

        /// <summary>
        /// Создает излом на ломанной линии.
        /// </summary>
        public void Bend(Polyline polyline)
        {
            var point = Mouse.GetPosition(canvas);
            var sections = new List<Section>();
            for (int i = 1; i < polyline.Points.Count; i++)
                sections.Add(new Section(polyline.Points[i - 1], polyline.Points[i]));
            Point? previous = null;
            var position = manager.GetLeftTop(polyline);
            foreach (var section in sections.OrderBy(s => s.GetDistance(point)))
            {
                var p1 = new Point(section.Point1.X + position.X, section.Point1.Y + position.Y);
                var p2 = new Point(section.Point2.X + position.X, section.Point2.Y + position.Y);
                var l1 = (point - p1).Length;
                var l2 = (point - p2).Length;
                if (l1 < section.Length && l2 < section.Length)
                {
                    previous = section.Point1;
                    break;
                }
            }
            if (previous.HasValue)
            {
                for (int i = 0; i < polyline.Points.Count; i++)
                {
                    if (polyline.Points[i] == previous.Value)
                    {
                        polyline.Points.Insert(i + 1, new Point(point.X - position.X, point.Y - position.Y));
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Перемещает излом ломанной линии.
        /// </summary>
        public void Edit(Polyline polyline)
        {
            if (tempElements != null && tempElements.Count > 0)
            {
                manager.State = EditorState.Stretching;
                var mouse = Mouse.GetPosition(canvas);
                var circle = tempElements.OrderBy(t => (mouse - new Point(Canvas.GetLeft(t) + t.Width / 2, Canvas.GetTop(t) + t.Height / 2)).Length).First();
                double treshold = polyline.StrokeThickness + circle.Height / 2;
                var index = tempElements.IndexOf(circle);
                var lt = manager.GetLeftTop(polyline);
                var point = new Point(mouse.X - lt.X, mouse.Y - lt.Y);
                if ((index > 0 && (point - polyline.Points[index - 1]).Length < treshold) || (index < polyline.Points.Count - 1 && (point - polyline.Points[index + 1]).Length < treshold))
                {
                    polyline.Points.RemoveAt(index);
                    canvas.Children.Remove(circle);
                    tempElements.Remove(circle);
                }
                else
                {
                    polyline.Points[index] = point;
                    manager.SetLeftTop(circle, mouse.X - circle.Width / 2, mouse.Y - circle.Height / 2);
                }
            }
        }

        /// <summary>
        /// Перемещает ломанную линию.
        /// </summary>
        /// <param name="vector"></param>
        public void Move(Polyline polyline, Vector vector)
        {
            manager.Move(polyline, vector);
            if (tempElements != null)
            {
                for (int i = 0; i < tempElements.Count; i++)
                    manager.Move((Shape)tempElements[i], vector);
            }
        }

        /// <summary>
        /// Удаляет ломанную линию.
        /// </summary>
        public void Delete(Polyline polyline)
        {
            canvas.Children.Remove(polyline);
            Deselect();
        }

        /// <summary>
        /// Устанавливает толщину ломанной линии.
        /// </summary>
        /// <param name="polyline">Ломанная линия.</param>
        /// <param name="thickness">Толщина.</param>
        public void SetThickness(Polyline polyline, int thickness)
        {
            if (polyline.StrokeThickness != thickness)
            {
                polyline.StrokeThickness = thickness;
                Deselect();
                Select(polyline);
            }
        }

        /// <summary>
        /// Устанавливает цвет ломанной линии.
        /// </summary>
        /// <param name="polyline">Ломанная линия.</param>
        /// <param name="color">Цвет.</param>
        public void Dye(Polyline polyline, Color color)
        {
            polyline.Stroke = new SolidColorBrush(color);
        }

        /// <summary>
        /// Возвращает цвет фигуры.
        /// </summary>
        public Color GetColor(Polyline polyline)
        {
            return ((SolidColorBrush)polyline.Stroke).Color;
        }

        void circle_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }
    }
}
