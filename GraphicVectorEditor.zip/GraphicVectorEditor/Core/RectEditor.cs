﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core
{
    public class RectEditor
    {
        ShapeEditor manager;

        Canvas canvas;

        public RectEditor(ShapeEditor manager, Canvas canvas)
        {
            this.manager = manager;
            this.canvas = canvas;
        }

        /// <summary>
        /// Изменяет размер прямоугольника.
        /// </summary>
        public void Stretch(Rectangle rect)
        {
            manager.State = EditorState.Stretching;
            var lt = manager.GetLeftTop(rect);
            var mouse = Mouse.GetPosition(canvas);
            Vector vector1;
            var angle = rect.RenderTransform is RotateTransform ? ((RotateTransform)rect.RenderTransform).Angle : 0;
            if (angle != 0)
            {
                var vector0 = (Vector)rect.Tag;
                var center = manager.GetCenter(rect, lt);
                vector1 = mouse - center;
                vector1 = manager.RotateVector(vector1, -angle);
                vector1 -= vector0;
                vector0 = manager.RotateVector(vector0, angle);
                var O = center + vector0;
                vector0 = -vector1 / 2;
                vector0 = manager.RotateVector(vector0, angle);
                var O_ = lt + vector1 / 2 + vector0;
                lt += O - O_;
                manager.SetLeftTop(rect, lt.X, lt.Y);
            }
            else
                vector1 = mouse - lt;
            if (vector1.X > 0 && vector1.Y > 0)
            {
                rect.Width = vector1.X;
                rect.Height = vector1.Y;
                rect.Tag = -vector1 / 2;
                if (angle != 0)
                    rect.RenderTransform = new RotateTransform(angle, vector1.X / 2, vector1.Y / 2);
            }
        }

        /// <summary>
        /// Устанавливает цвет прямоугольника.
        /// </summary>
        /// <param name="rect">Прямоугольник.</param>
        /// <param name="color">Цвет.</param>
        public void Dye(Rectangle rect, Color color)
        {
            rect.Fill = new SolidColorBrush(color);
        }

        /// <summary>
        /// Возвращает цвет фигуры.
        /// </summary>
        public Color GetColor(Rectangle rect)
        {
            return ((SolidColorBrush)rect.Fill).Color;
        }
    }
}
