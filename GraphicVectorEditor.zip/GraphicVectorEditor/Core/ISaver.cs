﻿using System;
using System.Collections.Generic;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Core
{
    public interface ISaver
    {
        void Save(double x, double y, System.Windows.Controls.Canvas canvas);

        Tuple<double, double, List<Shape>> Open();
    }
}
