﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Entities
{
    [Serializable]
    public class PolylineModel : ShapeModel
    {
        public double Thickness { get; set; }
        public List<Point> Points { get; set; }

        public PolylineModel()
        { }

        public PolylineModel(Polyline polyline) :
            base(polyline)
        {
            var color = ((SolidColorBrush)polyline.Stroke).Color;
            R = color.R;
            G = color.G;
            B = color.B;
            Thickness = polyline.StrokeThickness;
            Points = polyline.Points.ToList();
        }

        public override Shape Convert()
        {
            var polyline = new Polyline();
            polyline.Stroke = GetBrush();
            polyline.StrokeThickness = Thickness;
            polyline.FillRule = FillRule.EvenOdd;
            var points = new PointCollection();
            for (int i = 0; i < Points.Count; i++)
                points.Add(Points[i]);
            polyline.Points = points;
            SetPosition(polyline);
            return polyline;
        }
    }
}
