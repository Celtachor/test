﻿using GraphicVectorEditor.Creation;
using System;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Entities.Models
{
    [Serializable]
    public class RectModel : ShapeModel
    {
        public double Width { get; set; }
        public double Height { get; set; }
        public double Angle { get; set; }

        public RectModel()
        { }

        public RectModel(Rectangle rect) :
            base(rect)
        {
            var color = ((SolidColorBrush)rect.Fill).Color;
            R = color.R;
            G = color.G;
            B = color.B;
            Width = rect.Width;
            Height = rect.Height;
            if (rect.RenderTransform != null && rect.RenderTransform is RotateTransform)
                Angle = ((RotateTransform)rect.RenderTransform).Angle;
        }

        public override Shape Convert()
        {
            var rect = RectCreator.Create(Width, Height, GetColor());
            SetPosition(rect);
            if (Angle != 0)
            {
                var rotateTransform = new RotateTransform(Angle, Width / 2, Height / 2);
                rect.RenderTransform = rotateTransform;
            }
            return rect;
        }
    }
}
