﻿using GraphicVectorEditor.Creation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Entities.Models
{
    [Serializable]
    public class PolylineModel : ShapeModel
    {
        public double Thickness { get; set; }
        public List<Point> Points { get; set; }

        public PolylineModel()
        { }

        public PolylineModel(Polyline polyline) :
            base(polyline)
        {
            var color = ((SolidColorBrush)polyline.Stroke).Color;
            R = color.R;
            G = color.G;
            B = color.B;
            Thickness = polyline.StrokeThickness;
            Points = polyline.Points.ToList();
        }

        public override Shape Convert()
        {
            var polyline = PolylineCreator.Create(GetBrush(), Thickness, Points);
            SetPosition(polyline);
            return polyline;
        }
    }
}
