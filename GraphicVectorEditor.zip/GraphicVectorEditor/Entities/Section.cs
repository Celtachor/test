﻿using System;
using System.Windows;

namespace GraphicVectorEditor.Entities
{
    class Section
    {
        public Point Point1 { get; private set; }
        public Point Point2 { get; private set; }

        double? length;
        public double Length
        {
            get
            {
                if (!length.HasValue)
                    length = GetLength();
                return length.Value;
            }
        }

        double? a;
        public double A
        {
            get
            {
                if (!a.HasValue)
                    a = Point2.Y - Point1.Y;
                return a.Value;
            }
        }

        double? b;
        public double B
        {
            get
            {
                if (!b.HasValue)
                    b = Point1.X - Point2.X;
                return b.Value;
            }
        }

        double? c;
        public double C
        {
            get
            {
                if (!c.HasValue)
                    c = -A * Point1.X - B * Point1.Y;
                return c.Value;
            }
        }

        double? sqrt;
        public double Sqrt
        {
            get
            {
                if (!sqrt.HasValue)
                    sqrt = Math.Sqrt(A * A + B * B);
                return sqrt.Value;
            }
        }

        public Section(Point point1, Point point2)
        {
            Point1 = point1;
            Point2 = point2;
        }

        public double GetDistance(Point point)
        {
            return Math.Abs(A * point.X + B * point.Y + C) / Sqrt;
        }

        private double GetLength()
        {
            return (Point2 - Point1).Length;
        }
    }
}
