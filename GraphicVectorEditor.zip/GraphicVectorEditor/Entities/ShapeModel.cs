﻿using System;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Entities
{
    [Serializable]
    public abstract class ShapeModel
    {
        public double X { get; set; }
        public double Y { get; set; }
        public byte R { get; set; }
        public byte G { get; set; }
        public byte B { get; set; }

        public ShapeModel()
        { }

        public ShapeModel(Shape shape)
        {
            X = Canvas.GetLeft(shape);
            Y = Canvas.GetTop(shape);
        }

        protected void SetPosition(Shape shape)
        {
            Canvas.SetLeft(shape, X);
            Canvas.SetTop(shape, Y);
        }

        protected Color GetColor()
        {
            var color = new Color();
            color.A = 255;
            color.R = R;
            color.G = G;
            color.B = B;
            return color;
        }

        protected SolidColorBrush GetBrush()
        {
            return new SolidColorBrush(GetColor());
        }

        public abstract Shape Convert();
    }
}
