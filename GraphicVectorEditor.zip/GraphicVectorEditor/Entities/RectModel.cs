﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Entities
{
    [Serializable]
    public class RectModel : ShapeModel
    {
        public double Width { get; set; }
        public double Height { get; set; }
        public double Angle { get; set; }

        public RectModel()
        { }

        public RectModel(Rectangle rect) :
            base(rect)
        {
            var color = ((SolidColorBrush)rect.Fill).Color;
            R = color.R;
            G = color.G;
            B = color.B;
            Width = rect.Width;
            Height = rect.Height;
            if (rect.RenderTransform != null && rect.RenderTransform is RotateTransform)
                Angle = ((RotateTransform)rect.RenderTransform).Angle;
        }

        public override Shape Convert()
        {
            var rect = new Rectangle();
            rect.Width = Width;
            rect.Height = Height;
            var color = GetColor();
            if (color == Colors.White)
                rect.Stroke = Brushes.Black;
            else
                rect.Stroke = new SolidColorBrush(color);
            rect.StrokeThickness = 1;
            var vector = new Vector(-Width / 2, -Width / 2);
            rect.Tag = vector;
            rect.Fill = new SolidColorBrush(color);
            SetPosition(rect);
            if (Angle != 0)
            {
                var rotateTransform = new RotateTransform(Angle, -vector.X, -vector.Y);
                rect.RenderTransform = rotateTransform;
            }
            return rect;
        }
    }
}
