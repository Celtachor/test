﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Entities
{
    [Serializable]
    public class ProjectModel
    {
        public double X { get; set; }
        public double Y { get; set; }

        public List<ShapeModel> Shapes { get; set; }

        public ProjectModel()
        { }

        public ProjectModel(double x, double y, Canvas canvas)
        {
            X = x;
            Y = y;
            Shapes = new List<ShapeModel>();
            for (int i = 0; i < canvas.Children.Count; i++)
            {
                var shape = canvas.Children[i];
                if (shape is Rectangle)
                    Shapes.Add(new RectModel((Rectangle)shape));
                else if (shape is Polyline)
                    Shapes.Add(new PolylineModel((Polyline)shape));
                else
                    throw new Exception("Unknown type of shape");
            }
        }

        public Tuple<double, double, List<Shape>> Convert()
        {
            var shapes = new List<Shape>();
            for (int i = 0; i < Shapes.Count; i++)
                shapes.Add(Shapes[i].Convert());
            return new Tuple<double, double, List<Shape>>(X, Y, shapes);
        }
    }
}
