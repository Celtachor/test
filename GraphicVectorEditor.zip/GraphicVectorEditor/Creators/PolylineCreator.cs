﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Creation
{
    class PolylineCreator : ShapeCreator
    {
        static Point point0 = new Point(0, 0);

        static Point point1 = new Point(30, 0);

        public override Shape Create()
        {
            var polyline = new Polyline();
            polyline.Stroke = Brushes.Black;
            polyline.StrokeThickness = 1;
            polyline.FillRule = FillRule.EvenOdd;
            var points = new PointCollection();
            points.Add(point0);
            points.Add(point1);
            polyline.Points = points;
            return polyline;
        }
    }
}
