﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Creation
{
    class PolylineCreator : ShapeCreator
    {
        static Point point0 = new Point(0, 0);

        static Point point1 = new Point(30, 0);

        public override Shape Create()
        {
            return Create(Brushes.Black, 1, new List<Point> { point0, point1 });
        }

        public static Polyline Create(Brush brush, double thickness, List<Point> points)
        {
            var polyline = new Polyline();
            polyline.Stroke = brush;
            polyline.StrokeThickness = thickness;
            polyline.FillRule = FillRule.EvenOdd;
            var pointCollection = new PointCollection();
            for (int i = 0; i < points.Count; i++)
                pointCollection.Add(points[i]);
            polyline.Points = pointCollection;
            return polyline;
        }
    }
}
