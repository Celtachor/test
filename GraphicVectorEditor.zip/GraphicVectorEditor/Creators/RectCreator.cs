﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Creation
{
    class RectCreator : ShapeCreator
    {
        static double initialWidth = 30;

        static double initialHeight = 30;

        public override Shape Create()
        {
            {
                var rect = new Rectangle();
                rect.Width = initialWidth;
                rect.Height = initialHeight;
                rect.Stroke = Brushes.Black;
                rect.StrokeThickness = 1;
                rect.Tag = new Vector(-initialWidth / 2, -initialWidth / 2);
                rect.Fill = Brushes.White;
                return rect;
            }
        }
    }
}
