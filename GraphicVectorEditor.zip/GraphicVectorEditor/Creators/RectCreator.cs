﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Creation
{
    class RectCreator : ShapeCreator
    {
        static double initialWidth = 30;

        static double initialHeight = 30;

        public override Shape Create()
        {
            return Create(initialWidth, initialHeight, Colors.White);
        }

        public static Rectangle Create(double width, double height, Color color)
        {
            var rect = new Rectangle();
            rect.Width = width;
            rect.Height = height;
            if (color == Colors.White)
                rect.Stroke = Brushes.Black;
            else
                rect.Stroke = new SolidColorBrush(color);
            rect.StrokeThickness = 1;
            var vector = new Vector(-width / 2, -height / 2);
            rect.Tag = vector;
            rect.Fill = new SolidColorBrush(color);
            return rect;
        }
    }
}
