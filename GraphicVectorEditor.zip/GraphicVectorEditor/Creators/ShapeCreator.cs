﻿using System;
using System.Windows.Shapes;

namespace GraphicVectorEditor.Creation
{
    abstract class ShapeCreator
    {
        public static Shape Create(string tag)
        {
            ShapeCreator creator;
            switch (tag)
            {
                case "Rect": creator = new RectCreator(); break;
                case "Polyline": creator = new PolylineCreator(); break;
                default: throw new Exception("Unknown type of shape");
            }
            return creator.Create();
        }

        public abstract Shape Create();
    }
}
