﻿using GraphicVectorEditor.Entities;
using GraphicVectorEditor.Entities.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace GraphicVectorEditor.IO
{
    public class XmlIOHelper : IIOHelper
    {
        public void Save(double x, double y, System.Windows.Controls.Canvas canvas)
        {
            var serializer = new XmlSerializer(typeof(ProjectModel), new Type[] { typeof(ShapeModel), typeof(RectModel), typeof(PolylineModel) });
            using (var dialog = new SaveFileDialog())
            {
                dialog.Filter = "XML Files (*.xml)|*.xml";
                dialog.RestoreDirectory = true;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    using (FileStream stream = new FileStream(dialog.FileName, FileMode.Create))
                    {
                        serializer.Serialize(stream, new ProjectModel(x, y, canvas));
                    }
                }
            }
        }

        public Tuple<double, double, List<Shape>> Open()
        {
            var serializer = new XmlSerializer(typeof(ProjectModel), new Type[] { typeof(ShapeModel), typeof(RectModel), typeof(PolylineModel) });
            using (var dialog = new OpenFileDialog())
            {
                dialog.Filter = "XML Files (*.xml)|*.xml";
                dialog.RestoreDirectory = true;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    using (var stream = new FileStream(dialog.FileName, FileMode.Open))
                    {
                        var project = (ProjectModel)serializer.Deserialize(stream);
                        return project.Convert();
                    }
                }
            }
            return null;
        }
    }
}
