﻿using GraphicVectorEditor.Core;
using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.UI
{
    public class ActiveShapeFSM
    {
        TextBox tbThickness;

        Grid grdColor;

        EditorManager editorManager;

        Dictionary<Type, Action> statesToAction;

        public ActiveShapeFSM(TextBox tbThickness, Grid grdColor, EditorManager shapeEditor)
        {
            this.tbThickness = tbThickness;
            this.grdColor = grdColor;
            this.editorManager = shapeEditor;
            FillDictionary();
        }

        private void FillDictionary()
        {
            statesToAction = new Dictionary<Type, Action>();
            statesToAction.Add(typeof(Rectangle), () =>
            {
                tbThickness.Text = null;
                tbThickness.IsEnabled = false;
                grdColor.Background = new SolidColorBrush(editorManager.GetSelectedShapeColor().Value);
                grdColor.IsEnabled = true;
            });
            statesToAction.Add(typeof(Polyline), () =>
            {
                tbThickness.Text = Convert.ToInt32(((Polyline)editorManager.SelectedShape).StrokeThickness).ToString();
                tbThickness.IsEnabled = true;
                grdColor.Background = new SolidColorBrush(editorManager.GetSelectedShapeColor().Value);
                grdColor.IsEnabled = true;
            });
        }

        public void Update(Type type)
        {
            if (type == null)
            {
                tbThickness.Text = null;
                tbThickness.IsEnabled = false;
                grdColor.IsEnabled = false;
            }
            else
                statesToAction[type].Invoke();
        }
    }
}
