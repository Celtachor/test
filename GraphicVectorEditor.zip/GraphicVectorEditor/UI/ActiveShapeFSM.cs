﻿using GraphicVectorEditor.Core;
using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace GraphicVectorEditor.UI
{
    public class ActiveShapeFSM
    {
        TextBox tbThickness;

        Grid grdColor;

        ShapeEditor shapeEditor;

        Dictionary<Type, Action> statesToAction;

        public ActiveShapeFSM(TextBox tbThickness, Grid grdColor, ShapeEditor shapeEditor)
        {
            this.tbThickness = tbThickness;
            this.grdColor = grdColor;
            this.shapeEditor = shapeEditor;
            FillDictionary();
        }

        private void FillDictionary()
        {
            statesToAction = new Dictionary<Type, Action>();
            statesToAction.Add(typeof(Rectangle), () =>
            {
                tbThickness.Text = null;
                tbThickness.IsEnabled = false;
                grdColor.Background = new SolidColorBrush(shapeEditor.GetSelectedShapeColor().Value);
            });
            statesToAction.Add(typeof(Polyline), () =>
            {
                tbThickness.Text = Convert.ToInt32(((Polyline)shapeEditor.SelectedShape).StrokeThickness).ToString();
                tbThickness.IsEnabled = true;
                grdColor.Background = new SolidColorBrush(shapeEditor.GetSelectedShapeColor().Value);
            });
        }

        public void Update(Type type)
        {
            if (type == null)
            {
                tbThickness.Text = null;
                tbThickness.IsEnabled = false;
            }
            else
                statesToAction[type].Invoke();
            Keyboard.ClearFocus();
        }
    }
}
