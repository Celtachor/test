﻿using System;
using System.Windows;

namespace GraphicVectorEditor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
        }

        void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var ex = e.ExceptionObject as Exception;
            // В боевом варианте здесь, конечно, следует логировать.
            MessageBox.Show(this, ex == null ? "Unknown exception" : ex.Message, "ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
